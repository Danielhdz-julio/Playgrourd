# Test Plan básico

## Objetivo
Validar el flujo de login y algunos endpoints API base para asegurar comportamiento funcional correcto.

## Alcance
- UI: Login
- API: Endpoint `/users`

## Tipos de prueba
- Smoke
- Funcional
- Negativas

## Criterios de entrada
- Ambiente disponible
- Dependencias instaladas
- Datos de prueba definidos

## Criterios de salida
- 100% de casos smoke ejecutados
- Defectos críticos documentados

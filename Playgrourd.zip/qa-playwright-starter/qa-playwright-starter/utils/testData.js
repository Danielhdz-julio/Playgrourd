const users = {
  valid: {
    username: 'student',
    password: 'Password123'
  },
  invalid: {
    username: 'wrongUser',
    password: 'wrongPass'
  }
};

module.exports = { users };

const { test, expect } = require('@playwright/test');
const { LoginPage } = require('../../pages/LoginPage');
const { users } = require('../../utils/testData');

test.describe('Login UI', () => {
  test('debe iniciar sesión correctamente con credenciales válidas', async ({ page }) => {
    const loginPage = new LoginPage(page);

    await loginPage.open();
    await loginPage.login(users.valid.username, users.valid.password);

    await expect(page).toHaveURL(/logged-in-successfully/);
    await expect(loginPage.successMessage).toHaveText('Logged In Successfully');
  });

  test('debe mostrar error con credenciales inválidas', async ({ page }) => {
    const loginPage = new LoginPage(page);

    await loginPage.open();
    await loginPage.login(users.invalid.username, users.invalid.password);

    await expect(loginPage.errorMessage).toContainText('Your username is invalid!');
  });
});
